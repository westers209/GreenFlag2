package com.example.alicia.greenflag2;

import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class UserDetails extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText name,username,password,age,postal;
    ImageButton changePhoto, save;
    Spinner birthDate,country;
    RadioButton male,female,notSpecified;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);

        String passwordReceived = getIntent().getStringExtra("password");

        name = findViewById(R.id.et_name);
        username = findViewById(R.id.et_username);
        password = findViewById(R.id.et_password);
        age = findViewById(R.id.et_age);
        postal = findViewById(R.id.et_postal_address);
        changePhoto = findViewById(R.id.ib_change_photo);
        save = findViewById(R.id.ib_save);

        birthDate = findViewById(R.id.sp_birthmonth);
        country = findViewById(R.id.sp_country);

        male = findViewById(R.id.rb_male);
        female = findViewById(R.id.rb_female);
        notSpecified = findViewById(R.id.rb_not_specified);

        password.setText(passwordReceived);

        birthDate.setOnItemSelectedListener(this);
        String months[] = getResources().getStringArray(R.array.months);

        country.setOnItemSelectedListener(this);
        String country_selection[] = getResources().getStringArray(R.array.country_selection);

        ArrayAdapter<String> monthsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,country_selection);
        ArrayAdapter<String> countryAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,months);

        birthDate.setAdapter(monthsAdapter);
        country.setAdapter(countryAdapter);


        save.setOnClickListener(v -> {
            String nameValue = name.getText().toString();
            String postalValue = postal.getText().toString();
            String birthDateSelection = birthDate.getSelectedItem().toString();
            String countrySelection = country.getSelectedItem().toString();
            String radioSelection;
            if (female.isChecked()) {
                radioSelection = female.getText().toString();
            } else if (male.isChecked()) {
                radioSelection = male.getText().toString();
            } else {
                radioSelection = notSpecified.getText().toString();
            }

            Intent intent = new Intent(this, AllAccounts.class);
            Bundle extras = new Bundle();
            extras.putString("name",nameValue);
            extras.putString("postal address",postalValue);
            extras.putString("birth date",birthDateSelection);
            extras.putString("country",countrySelection);
            extras.putString("gender",radioSelection);
            intent.putExtras(extras);

            startActivity(intent);
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
