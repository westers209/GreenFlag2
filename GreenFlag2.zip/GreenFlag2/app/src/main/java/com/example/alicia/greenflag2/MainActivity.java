package com.example.alicia.greenflag2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    ImageButton button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Hide the Status bar.
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        //Hide the Action bar
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        //Had issues with trying to use butterknife. I believe it was the same problem we ran into the first time you showed us butterknife.
        button = findViewById(R.id.ib_next);

        //Move to create account.
        button.setOnClickListener(v -> {
            Intent intent = new Intent(this,CreateAccount.class);
            startActivity(intent);
        });
    }
}
