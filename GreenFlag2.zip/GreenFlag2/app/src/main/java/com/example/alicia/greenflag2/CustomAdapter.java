package com.example.alicia.greenflag2;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<UserViewHolder>{

    List<Users> UsersList;
    Context context;

    public CustomAdapter(List<Users>UsersList){
        this.UsersList = UsersList;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_layout,viewGroup,false);
        context = viewGroup.getContext();
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder userViewHolder, int i) {
        Users users = UsersList.get(i);

        userViewHolder.name.setText(users.getName());
        userViewHolder.postal.setText(users.getPostal());
        userViewHolder.birthDate.setText(users.getBirthDate());
        userViewHolder.country.setText(users.getCountry());
        userViewHolder.gender.setText(users.getGender());
    }

    @Override
    public int getItemCount() {
        return UsersList == null ? 0 : UsersList.size();
    }
}
