package com.example.alicia.greenflag2;

import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

public class UserViewHolder extends RecyclerView.ViewHolder {
     TextView name;
     TextView postal;
     TextView birthDate;
     TextView country;
     TextView gender;
     CardView cardView;

    public UserViewHolder(@NonNull View itemView) {
        super(itemView);

        cardView = itemView.findViewById(R.id.cardView);
        name = itemView.findViewById(R.id.tv_name);
        postal = itemView.findViewById(R.id.tv_postal);
        birthDate = itemView.findViewById(R.id.tv_birth_month);
        country = itemView.findViewById(R.id.tv_country);
        gender = itemView.findViewById(R.id.tv_gender);
    }
}
