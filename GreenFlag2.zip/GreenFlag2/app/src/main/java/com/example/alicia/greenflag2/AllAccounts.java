package com.example.alicia.greenflag2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class AllAccounts extends AppCompatActivity {

    RecyclerView recyclerView;
    CustomAdapter customAdapter;
    ArrayList<Users> users;

    //Runtime exception here caused by Null Pointer Exception. Probably should use parcelable here but this should still work but I'm missing something.
    Bundle extras = getIntent().getExtras();
    public final String name = extras.getString("name");
    public final String postal = extras.getString("postal address");
    public final String birthDate = extras.getString("birth date");
    public final String country = extras.getString("country");
    public final String gender = extras.getString("gender");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_accounts);

        Users user = new Users();

        user.setName(name);
        user.setPostal(postal);
        user.setBirthDate(birthDate);
        user.setCountry(country);
        user.setGender(gender);

        users.add(user);

        recyclerView = findViewById(R.id.my_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(customAdapter);

    }
}
