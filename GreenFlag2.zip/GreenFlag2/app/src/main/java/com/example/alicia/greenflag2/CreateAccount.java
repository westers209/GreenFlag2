package com.example.alicia.greenflag2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CreateAccount extends AppCompatActivity {

    ImageButton ibBack, ibNext;
    EditText emailAddress, createPassword, repeatPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Hide the Status bar
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        //Hide the Action bar
        getSupportActionBar().hide();
        setContentView(R.layout.activity_create_account);

        //Bind the views
        ibBack = findViewById(R.id.ib_back);
        ibNext = findViewById(R.id.ib_next);
        emailAddress = findViewById(R.id.et_email_address);
        createPassword = findViewById(R.id.et_create_password);
        repeatPassword = findViewById(R.id.et_repeat_password);



        //Button to go back to the starting screen.
        ibBack.setOnClickListener(v -> {
            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);
        });

        ibNext.setOnClickListener(v -> {
            Intent intent = new Intent(this, UserDetails.class);

            //Get the values from the EditTexts
            String emailAddressValue = emailAddress.getText().toString();
            String createPasswordValue = createPassword.getText().toString();
            String repeatPasswordValue = repeatPassword.getText().toString();

            //validatePassword(createPasswordValue) && validatePassword(repeatPasswordValue) && validateEmail(emailAddressValue)
            //Forcing the button to work for now. todo get the regex validation to work
            if(true){
                Toast.makeText(this, createPasswordValue, Toast.LENGTH_SHORT).show();
                intent.putExtra("password",createPasswordValue);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Invalid Email or Password", Toast.LENGTH_LONG).show();
            }
        });
    }

    private static boolean validateEmail(final String email){
        Pattern pattern;
        Matcher matcher;

        final String EMAIL_PATTERN = "^(?=.*[a-z])" +
                "(?=.*[A-Z])" +
                "(?=.*\\d)" +
                "@" +
                "(?=.*[a-z])" +
                "(?=.*[A-Z])" +
                "(?=.*\\d)" +
                "." +
                "(?=.*[a-z])";

        pattern = Pattern.compile(EMAIL_PATTERN);
        matcher = pattern.matcher(email);

        return matcher.matches();
    }

    //Password validation through regex
    private static boolean validatePassword(final String password){
        Pattern pattern;
        Matcher matcher;

        //Validate Lowercase
        //Uppercase
        //Digits
        //Special characters can be used.
        //No white space allowed
        //8 characters min, no max.
        final String PASSWORD_PATTERN = "^(?=.*\\\\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();
    }
}
